import {createSchedule,selectEvent,applyEventChoice} from './race-events.mjs';
import {markRetired} from './retirement.mjs';
import {tracksFor,performance,race} from './engine.mjs';
import {carStats} from './development.mjs';
const clamp=(n,a,b)=>Math.max(a,Math.min(b,n));
export {CIRCUITS,roundedTrack} from './track-geometry.mjs';
export function formatLap(seconds){if(!Number.isFinite(seconds))return '—';const ms=Math.max(0,Math.round(seconds*1000));return `${Math.floor(ms/60000)}:${String(Math.floor(ms/1000)%60).padStart(2,'0')}.${String(ms%1000).padStart(3,'0')}`}
export function startLive(s,strategy,rng=Math.random){if(s.phase!=='qualified')return false;s.live={stage:0,lap:0,total:tracksFor(s)[s.round].laps,strategy,tyre:'M',wear:100,temp:85,ers:75,fuel:100,weather:'dry',pace:0,risk:0,retired:false,event:null,radio:'스타트 완료. 컨디션과 타이어를 살피면서 페이스를 만들어 가자.',messages:[],cars:s.grid.map((id,i)=>({id,time:0,startDelay:i*.22,retired:false,wear:100,pitted:false,wetTyre:false})),lastOrder:[...s.grid],lastLap:0,lapHistory:[],bestLap:null,lastLapTime:null,pendingPenalty:0,totalTime:0,telemetryTrace:[]};s.live.schedule=createSchedule(s.live.total,rng);s.live.seenEvents=[];s.live.recentEvents=(s.results.at(-1)?.decisions??[]).map(m=>m.kind).filter(Boolean);s.phase='racing';return true}
export function runningOrder(s){return [...s.live.cars].sort((a,b)=>Number(a.retired)-Number(b.retired)||a.time-b.time)}
export function makeEvent(s,rng){return selectEvent(s,rng)}
export function progressLive(s,rng){const l=s.live;if(s.phase!=='racing'||!l||l.event)return false;l.lastOrder=runningOrder(s).map(c=>c.id);l.lastLap=l.lap;l.stage++;const end=l.schedule[l.stage-1]?.lap??l.total;const car=carStats(s),base=tracksFor(s)[s.round].baseLap;l.telemetryTrace=[];const pending=l.pendingPenalty??0;l.pendingPenalty=0;
for(let lap=l.lap+1;lap<=end&&!l.retired;lap++){
 const order=runningOrder(s),leader=order.find(c=>!c.retired)?.time??0,maxGap=Math.max(...order.filter(c=>!c.retired).map(c=>c.time-leader),0);let playerLap=0;
 for(const c of l.cars){if(c.retired)continue;const p=s.standing.find(p=>p.id===c.id),you=c.id==='you';let seconds=base+(75-performance(s,p,l.weather))*.085+(rng()-.5)*.65+(lap===1?c.startDelay??0:0);
 if(you){seconds+=(l.strategy==='attack'?-.22:l.strategy==='safe'?.09:0)+(l.tyre==='S'?-.27:l.tyre==='H'?.09:0);if(l.wear<40)seconds+=(40-l.wear)*.035;if(l.weather==='rain'&&l.tyre!=='I')seconds+=1.65;if(l.weather==='dry'&&l.tyre==='I')seconds+=1.1;seconds+=l.pace/Math.max(1,end-l.lastLap);const risk=((l.strategy==='attack'?.10:l.strategy==='safe'?.015:.035)+(s.energy<35?.04:0))*(1-(car.reliability-45)*.005);if(rng()<1-Math.pow(1-risk,1/l.total)){markRetired(s,c,'incident',lap)}else if(l.wear<9&&rng()<.08){markRetired(s,c,'puncture',lap)}if(lap===l.lastLap+1&&l.risk&&rng()<l.risk){markRetired(s,c,l.riskCause??(l.risk===.15?'wet_spin':l.risk===.07?'overpush':'unknown'),lap)}playerLap=seconds+(lap===l.lastLap+1?pending:0)}
 else{const otherCar=carStats(s,p.team);c.wear-=110/l.total*(1-(otherCar.tyres-45)*.003);if(c.wear<40)seconds+=(40-c.wear)*.035;if(!c.pitted&&lap>=Math.round(l.total*.48)){seconds+=12;c.pitted=true;c.wear=100}if(l.weather==='rain'&&!c.wetTyre){seconds+=12;c.wetTyre=true;c.wear=100}if(rng()<.025/l.total)markRetired(s,c,'incident',lap)}
 if(l.safety&&lap===l.lastLap+1){const delay=base*.3+maxGap-(c.time-leader)*.65;seconds+=Math.max(0,delay);if(you)playerLap+=Math.max(0,delay)}c.time+=Math.max(30,seconds);
 }
 l.wear=clamp(l.wear-110/l.total*(l.tyre==='S'?1.35:l.tyre==='H'?.72:1)*(l.strategy==='attack'?1.15:1)*(1-(car.tyres-45)*.003)*(1-(s.stats.tyre-45)*.002),0,100);
 l.temp=clamp(l.temp+((l.strategy==='attack'?.72:.38)-(car.reliability-45)*.006-(l.weather==='rain'?.5:0)),65,145);l.ers=clamp(l.ers+(l.strategy==='attack'?-.25:.3),0,100);l.fuel=clamp(100-lap/l.total*94,0,100);l.lap=lap;l.totalTime=l.cars.find(c=>c.id==='you').time;l.lastLapTime=playerLap;l.bestLap=l.bestLap===null?playerLap:Math.min(l.bestLap,playerLap);l.lapHistory.push({lap,time:playerLap,cumulative:l.totalTime,adjustment:lap===l.lastLap+1?pending:0});l.telemetryTrace.push({lap,wear:l.wear,temp:l.temp,ers:l.ers,fuel:l.fuel});
}
l.risk=0;l.riskCause=null;l.pace=0;l.safety=false;
if(l.lap>=l.total||l.retired){s.phase='qualified';const values=Object.fromEntries(l.cars.map(c=>[c.id,{value:-c.time,elapsed:c.time,dnf:c.retired}]));race(s,l.strategy,rng,{values,weather:l.weather});s.lastRace.decisions=[...l.messages];s.results[s.results.length-1].decisions=[...l.messages];return true}
l.event=makeEvent(s,rng);l.radio=l.event?.body??'현재 페이스 유지. 다음 상황을 살피고 있습니다.';return true}
export function chooseLive(s,id,rng){return applyEventChoice(s,id,rng)}
