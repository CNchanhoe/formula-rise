export function roundedTrack(points,radius=26){const corners=points.map((p,i)=>{const before=points[(i-1+points.length)%points.length],after=points[(i+1)%points.length],a=Math.hypot(before[0]-p[0],before[1]-p[1]),b=Math.hypot(after[0]-p[0],after[1]-p[1]),r=Math.min(radius,a*.35,b*.35);return {p,in:[p[0]+(before[0]-p[0])*r/a,p[1]+(before[1]-p[1])*r/a],out:[p[0]+(after[0]-p[0])*r/b,p[1]+(after[1]-p[1])*r/b]}});return `M${corners[0].out.join(' ')} `+corners.slice(1).concat(corners[0]).map(c=>`L${c.in.join(' ')} Q${c.p.join(' ')} ${c.out.join(' ')}`).join(' ')+' Z'}
export const TRACK_POINTS=[[[130,300],[160,80],[300,80],[345,145],[505,145],[545,65],[590,100],[565,275],[475,330],[405,270],[315,355],[130,355]],[[115,310],[115,100],[195,70],[225,150],[310,150],[340,105],[385,120],[400,205],[490,170],[560,210],[560,300],[510,320],[440,265],[365,335],[270,310],[205,350]],[[120,310],[155,180],[245,110],[360,95],[430,135],[550,90],[570,155],[495,220],[555,300],[475,350],[375,290],[285,350],[195,300]],[[110,300],[135,245],[230,200],[265,105],[345,65],[415,100],[440,180],[565,235],[540,325],[480,355],[385,275],[325,300],[240,350]],[[110,315],[145,95],[210,75],[240,125],[275,100],[535,80],[565,145],[555,250],[490,275],[470,230],[435,250],[380,330],[230,350]],[[110,280],[170,175],[245,155],[300,220],[350,260],[420,150],[485,105],[560,125],[575,205],[515,270],[430,280],[355,210],[280,110],[200,85],[130,145]]];
export const CIRCUITS=TRACK_POINTS.map(p=>roundedTrack(p));

// Suzuka uses the outside of its southeast straight, clear of the parallel esses.
const PIT_SEGMENTS=[1,0,2,6,4,8];
export const PIT_LANES=TRACK_POINTS.map((points,i)=>{
  const a=points[PIT_SEGMENTS[i]],b=points[(PIT_SEGMENTS[i]+1)%points.length];
  const dx=b[0]-a[0],dy=b[1]-a[1],length=Math.hypot(dx,dy),normal=[dy/length,-dx/length];
  const at=(t,offset=0)=>[a[0]+dx*t+normal[0]*offset,a[1]+dy*t+normal[1]*offset];
  const trim=Math.max(.2,28/length),entry=at(trim),exit=at(1-trim),offset=i===5?37:32;
  const c=at(.42,offset),d=at(.58,offset),center=at(.5,offset);
  return {entry,exit,center,label:at(.5,offset+(Math.abs(normal[0])>.45?39:33)),labelAnchor:normal[0]>.45?'start':normal[0]<-.45?'end':'middle',normal,angle:Math.atan2(dy,dx)*180/Math.PI,
    path:`M${entry} C${at(trim+.08)} ${at(.26,offset)} ${c} L${d} C${at(.74,offset)} ${at(.92-trim)} ${exit}`};
});
export function pitLaneMarkup(round){
  const p=PIT_LANES[round];
  const bays=Array.from({length:5},(_,i)=>`<rect x="${-16+i*6.5}" y="-18" width="5.2" height="7" rx=".7" fill="#536065"/><path d="M${-15+i*6.5} -9v3h4v-3" fill="none" stroke="#b5a575" stroke-width=".7"/>`).join('');
  return `<g class="pit-lane" aria-label="피트레인 입구와 출구">
    <path d="${p.path}" fill="none" stroke="#7d8b8e" stroke-width="9" stroke-linecap="round"/>
    <path id="pit-line" d="${p.path}" fill="none" stroke="#303a40" stroke-width="7"/>
    <path d="${p.path}" fill="none" stroke="#c4b27d" stroke-width=".65" stroke-dasharray="2 4"/>
    <g transform="translate(${p.center}) rotate(${p.angle})"><rect x="-19" y="-21" width="38" height="12" rx="1.5" fill="#1b252b" stroke="#59656b" stroke-width=".7"/>${bays}<path d="M-2 -2L1 0L-2 2" fill="none" stroke="#b9c5c9" stroke-width="1"/></g>
    <circle cx="${p.entry[0]}" cy="${p.entry[1]}" r="2" fill="#d4c190" stroke="#151e24"/>
    <circle cx="${p.exit[0]}" cy="${p.exit[1]}" r="2" fill="#82b7ce" stroke="#151e24"/>
    <text x="${p.label[0]}" y="${p.label[1]}" text-anchor="${p.labelAnchor}" dominant-baseline="middle" fill="#b0bdc3" stroke="#10191f" stroke-width="3" paint-order="stroke" font-size="8" letter-spacing="1.2" font-family="sans-serif">PIT LANE</text></g>`;
}
export const START_FINISH=PIT_LANES.map(p=>{
  const center=p.entry.map((v,i)=>(v+p.exit[i])/2),angle=p.angle;
  const radians=angle*Math.PI/180,inside=[-Math.sin(radians),Math.cos(radians)];
  return {center,angle,label:center.map((v,i)=>v+inside[i]*27),anchor:inside[0]>.45?'start':inside[0]<-.45?'end':'middle'};
});
export function startFinishMarkup(round){
  const f=START_FINISH[round];
  const squares=Array.from({length:14},(_,i)=>`<rect x="${-3+(i%2)*3}" y="${-10.5+Math.floor(i/2)*3}" width="3" height="3" fill="${(i%2+Math.floor(i/2))%2?'#172027':'#e0e5e7'}"/>`).join('');
  return `<g class="start-finish" aria-label="출발 · 결승선"><g transform="translate(${f.center}) rotate(${f.angle})">${squares}<path d="M0 13V20" stroke="#7c8c94" stroke-width=".7"/></g><text x="${f.label[0]}" y="${f.label[1]}" text-anchor="${f.anchor}" dominant-baseline="middle" fill="#9eafb9" stroke="#121c23" stroke-width="3" paint-order="stroke" font-size="7" letter-spacing=".8" font-family="sans-serif">START / FINISH</text></g>`;
}
// A single surface renderer keeps the paddock and live timing map in sync.
export function circuitSurfaceMarkup(round,{live=false,prefix=live?'race':'paddock'}={}){
  const d=CIRCUITS[round],points=TRACK_POINTS[round];
  // The figure-eight crossing is an overpass, never a four-way junction.
  const bridge=round===5?`<g fill="none"><path d="M362.7 240L380.9 211.3" stroke="#0a1219" stroke-width="29"/><path d="M362.7 240L380.9 211.3" stroke="#b0bec5" stroke-width="20"/><path d="M362.7 240L380.9 211.3" stroke="url(#${prefix}-asphalt)" stroke-width="18"/></g>`:'';
  const curbs=points.map((p,i)=>{
    const a=points[(i-1+points.length)%points.length],b=points[(i+1)%points.length];
    const la=Math.hypot(a[0]-p[0],a[1]-p[1]),lb=Math.hypot(b[0]-p[0],b[1]-p[1]),r=Math.min(26,la*.35,lb*.35);
    return `M${p[0]+(a[0]-p[0])*r/la} ${p[1]+(a[1]-p[1])*r/la} Q${p} ${p[0]+(b[0]-p[0])*r/lb} ${p[1]+(b[1]-p[1])*r/lb}`;
  }).join(' ');
  return `<defs><radialGradient id="${prefix}-ground"><stop stop-color="#1b2a32"/><stop offset="1" stop-color="#101920"/></radialGradient><linearGradient id="${prefix}-asphalt" x2="0" y2="1"><stop stop-color="#3b464d"/><stop offset="1" stop-color="#29363e"/></linearGradient></defs>
    <rect width="680" height="420" fill="url(#${prefix}-ground)"/>
    <g fill="none" stroke-linejoin="round" stroke-linecap="round">
      <path d="${d}" stroke="#0c1319" stroke-width="39" opacity=".7"/>
      <path d="${d}" stroke="#233936" stroke-width="32"/>
      <path d="${d}" stroke="#40534f" stroke-width="25" opacity=".6"/>
      <path d="${curbs}" stroke="#b8bfc0" stroke-width="24"/>
      <path d="${curbs}" stroke="#9b5656" stroke-width="24" stroke-dasharray="4 5"/>
      <path d="${d}" stroke="#a8b6bc" stroke-width="20"/>
      <path ${live?'id="race-line"':''} d="${d}" stroke="url(#${prefix}-asphalt)" stroke-width="18"/>
    </g>${bridge}${pitLaneMarkup(round)}${startFinishMarkup(round)}
    <g fill="#6e8491" font-family="sans-serif" font-size="7" letter-spacing="1.5"><text x="28" y="394">CIRCUIT / ${String(round+1).padStart(2,'0')}</text><text x="652" y="394" text-anchor="end">FORMULA RISE</text></g>`;
}
