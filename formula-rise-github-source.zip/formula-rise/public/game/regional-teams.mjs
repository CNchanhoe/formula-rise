// Fictional regional constructors; counts and car ratings preserve save compatibility.
export const F4_REGIONS = {
  "italy": {
    "label": "이탈리아 FR4",
    "country": "이탈리아",
    "description": "이탈리아 지역 리그 · 오리지널 팀 · 게임용 일정"
  },
  "britain": {
    "label": "영국 FR4",
    "country": "영국",
    "description": "영국 지역 리그 · 오리지널 팀 · 게임용 일정"
  },
  "spain": {
    "label": "스페인 FR4",
    "country": "스페인",
    "description": "스페인 지역 리그 · 오리지널 팀 · 게임용 일정"
  }
};
export const REGIONAL_TEAMS = {
  "britain": [
    {
      "id": "gb-cdr",
      "name": "Cirrus Garage",
      "short": "CIR",
      "color": "#bfd08b",
      "car": 0,
      "logo": "/constructor-marks/constructor-36.svg",
      "desc": "포뮬러 라이즈 오리지널 팀"
    },
    {
      "id": "gb-virtuosi",
      "name": "Redwood Motorsport",
      "short": "RED",
      "color": "#f1798b",
      "car": 1,
      "logo": "/constructor-marks/constructor-37.svg",
      "desc": "포뮬러 라이즈 오리지널 팀"
    },
    {
      "id": "gb-xcel",
      "name": "Vela Works",
      "short": "VEL",
      "color": "#d6c17e",
      "car": 2,
      "logo": "/constructor-marks/constructor-38.svg",
      "desc": "포뮬러 라이즈 오리지널 팀"
    },
    {
      "id": "gb-jhr",
      "name": "Astera Racing",
      "short": "AST",
      "color": "#e6a87e",
      "car": 2,
      "logo": "/constructor-marks/constructor-39.svg",
      "desc": "포뮬러 라이즈 오리지널 팀"
    },
    {
      "id": "gb-fortec",
      "name": "Mosaic Sport",
      "short": "MOS",
      "color": "#b2b8e2",
      "car": 3,
      "logo": "/constructor-marks/constructor-40.svg",
      "desc": "포뮬러 라이즈 오리지널 팀"
    },
    {
      "id": "gb-argenti",
      "name": "Fjord Circuit",
      "short": "FJO",
      "color": "#b9a0ef",
      "car": 4,
      "logo": "/constructor-marks/constructor-41.svg",
      "desc": "포뮬러 라이즈 오리지널 팀"
    },
    {
      "id": "gb-hitech",
      "name": "Prairie Motors",
      "short": "PRA",
      "color": "#a4c998",
      "car": 5,
      "logo": "/constructor-marks/constructor-42.svg",
      "desc": "포뮬러 라이즈 오리지널 팀"
    },
    {
      "id": "gb-rodin",
      "name": "Tern Racing",
      "short": "TER",
      "color": "#8db7bd",
      "car": 5,
      "logo": "/constructor-marks/constructor-43.svg",
      "desc": "포뮬러 라이즈 오리지널 팀"
    }
  ],
  "spain": [
    {
      "id": "es-grs",
      "name": "Prism Engineering",
      "short": "PRI",
      "color": "#87d2dc",
      "car": 0,
      "logo": "/constructor-marks/constructor-44.svg",
      "desc": "포뮬러 라이즈 오리지널 팀"
    },
    {
      "id": "es-g4",
      "name": "Asterlane",
      "short": "AST",
      "color": "#88b7f0",
      "car": 1,
      "logo": "/constructor-marks/constructor-45.svg",
      "desc": "포뮬러 라이즈 오리지널 팀"
    },
    {
      "id": "es-dxr",
      "name": "Delta Grove",
      "short": "DEL",
      "color": "#c4b0a0",
      "car": 1,
      "logo": "/constructor-marks/constructor-46.svg",
      "desc": "포뮬러 라이즈 오리지널 팀"
    },
    {
      "id": "es-tc",
      "name": "Lantern Motorsport",
      "short": "LAN",
      "color": "#bfd08b",
      "car": 2,
      "logo": "/constructor-marks/constructor-47.svg",
      "desc": "포뮬러 라이즈 오리지널 팀"
    },
    {
      "id": "es-monlau",
      "name": "Woven Racing",
      "short": "WOV",
      "color": "#f1798b",
      "car": 2,
      "logo": "/constructor-marks/constructor-48.svg",
      "desc": "포뮬러 라이즈 오리지널 팀"
    },
    {
      "id": "es-tecnicar",
      "name": "Aether Garage",
      "short": "AET",
      "color": "#d6c17e",
      "car": 3,
      "logo": "/constructor-marks/constructor-49.svg",
      "desc": "포뮬러 라이즈 오리지널 팀"
    },
    {
      "id": "es-campos",
      "name": "Canyon Works",
      "short": "CAN",
      "color": "#e6a87e",
      "car": 4,
      "logo": "/constructor-marks/constructor-50.svg",
      "desc": "포뮬러 라이즈 오리지널 팀"
    },
    {
      "id": "es-drivex",
      "name": "Solace Racing",
      "short": "SOL",
      "color": "#b2b8e2",
      "car": 3,
      "logo": "/constructor-marks/constructor-51.svg",
      "desc": "포뮬러 라이즈 오리지널 팀"
    },
    {
      "id": "es-kcl",
      "name": "Nacre Motorsport",
      "short": "NAC",
      "color": "#b9a0ef",
      "car": 4,
      "logo": "/constructor-marks/constructor-52.svg",
      "desc": "포뮬러 라이즈 오리지널 팀"
    },
    {
      "id": "es-tcode",
      "name": "Sequoia Works",
      "short": "SEQ",
      "color": "#a4c998",
      "car": 4,
      "logo": "/constructor-marks/constructor-53.svg",
      "desc": "포뮬러 라이즈 오리지널 팀"
    },
    {
      "id": "es-griffin",
      "name": "Flint Racing",
      "short": "FLI",
      "color": "#8db7bd",
      "car": 5,
      "logo": "/constructor-marks/constructor-54.svg",
      "desc": "포뮬러 라이즈 오리지널 팀"
    },
    {
      "id": "es-mp",
      "name": "Cedar Union",
      "short": "CED",
      "color": "#87d2dc",
      "car": 5,
      "logo": "/constructor-marks/constructor-55.svg",
      "desc": "포뮬러 라이즈 오리지널 팀"
    }
  ]
};
