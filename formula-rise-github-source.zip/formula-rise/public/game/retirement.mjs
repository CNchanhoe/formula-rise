// Race retirement is distinct from retiring an entire career.
export const RETIREMENT_CAUSES={
 incident:{title:'주행 중 사고',detail:'주행 중 사고로 레이스를 마치지 못했습니다.',tip:'컨디션을 회복하고 안정적인 전략을 선택하세요. 냉각·신뢰성 개발도 기본 위험을 줄입니다.'},
 puncture:{title:'타이어 펑크',detail:'잔여 수명이 낮은 타이어가 손상됐습니다.',tip:'타이어 수명이 낮아지면 피트에서 교체하세요.'},
 contact:{title:'추월 중 접촉',detail:'좁은 틈을 노린 추월 중 접촉이 발생했습니다.',tip:'접촉 위험이 부담된다면 ERS 추월이나 대기를 선택하세요.'},
 wet_spin:{title:'빗길 스핀',detail:'젖은 노면에서 슬릭 타이어로 버티다 스핀했습니다.',tip:'비가 오면 인터미디어 타이어로 교체하세요.'},
 braking_spin:{title:'제동 중 스핀',detail:'제동 배분 변경 후 차량이 균형을 잃었습니다.',tip:'제동이 불안정하면 일찍 브레이크를 밟으며 냉각하세요.'},
 overpush:{title:'무리한 공격 주행',detail:'마지막 공격으로 높아진 위험이 리타이어로 이어졌습니다.',tip:'마지막 스틴트에서는 타이어와 온도를 보고 페이스를 조절하세요.'},
 fire_damage:{title:'화재 후 차량 손상',detail:'소화·점검 후에도 차량 손상으로 복귀하지 못했습니다.',tip:'화재 경고가 나오면 긴급 피트 또는 안전 정차를 선택하세요.'},
 safety_stop:{title:'화재 경고 · 안전 정차',detail:'드라이버 보호를 위해 안전한 곳에 정차했습니다.',tip:'안전을 위한 선택입니다. 다음 그랑프리에서 다시 도전하세요.'},
 unknown:{title:'원인 미기록',detail:'이 저장 기록에는 자세한 리타이어 원인이 남아 있지 않습니다.',tip:'새로 발생하는 리타이어부터 원인과 발생 랩이 기록됩니다.'}
};
export function retirementInfo(record){const cause=RETIREMENT_CAUSES[record?.code]??RETIREMENT_CAUSES.unknown;return {...cause,lap:Number.isInteger(record?.lap)&&record.lap>0?record.lap:null}}
export function markRetired(s,car,code,lap){car.retired=true;car.retirement??={code,lap};if(car.id==='you'){s.live.retired=true;s.live.retirement??={...car.retirement};s.live.radio=retirementInfo(s.live.retirement).detail}}
