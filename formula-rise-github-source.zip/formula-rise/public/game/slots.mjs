// The legacy key remains a mirror for safe, non-destructive upgrade from a single career.
export const SLOT_KEY='formula-rise-careers-v1';
export const LEGACY_KEY='grid-to-glory-v1';
export function readSlots(storage,validate){
 const raw=storage.getItem(SLOT_KEY);
 if(raw){const bank=JSON.parse(raw);if(bank.version!==1||!Array.isArray(bank.slots)||bank.slots.length!==3||!Number.isInteger(bank.active)||bank.active<0||bank.active>2||bank.slots.some(s=>s!==null&&!validate(s)))throw new Error('커리어 보관함을 읽지 못했습니다. 원본 저장은 유지됩니다.');return bank;}
 const old=storage.getItem(LEGACY_KEY),state=old?JSON.parse(old):null;
 if(state&&!validate(state))throw new Error('기존 커리어를 읽지 못했습니다. 원본 저장은 유지됩니다.');
 return {version:1,active:0,slots:[state,null,null]};
}
export function persistSlots(storage,bank){storage.setItem(SLOT_KEY,JSON.stringify(bank));try{if(bank.slots[bank.active])storage.setItem(LEGACY_KEY,JSON.stringify(bank.slots[bank.active]));else storage.removeItem(LEGACY_KEY)}catch{/* The complete bank is already safely stored. */}}
export function selectSlot(bank,index,limit){if(!Number.isInteger(index)||index<0||index>=3)throw new Error('올바른 슬롯을 선택해주세요.');if(index>=limit)throw new Error('추가 슬롯 이용권을 확인해주세요.');return {...bank,active:index,slots:[...bank.slots]};}
export function putSlot(bank,state){const slots=[...bank.slots];slots[bank.active]=state;return {...bank,slots};}
