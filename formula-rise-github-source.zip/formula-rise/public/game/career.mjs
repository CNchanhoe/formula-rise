import * as legacy from './legacy-v4/career.mjs';
import {initializeDevelopment,upgradeCar} from './development.mjs';
import * as dynamicRace from './racing.mjs';
import * as raceV6 from './racing-v6.mjs';
import {createCareer,train,qualify,race,advance,nextSeason,overall,validSave} from './engine.mjs';

export const PALETTE=['#c5f567','#ff875d','#b3a0ff','#6ad4e6','#f4d35e','#e94f64','#f2f1e9','#252c42','#32967b','#ec89c6'];
export const HELMETS={classic:'클래식',stripe:'센터 스트라이프',split:'투톤',aero:'에어로',aurora:'오로라',ember:'엠버'};
export const SUITS={classic:'클래식',stripe:'레이싱 스트라이프',panel:'팀 패널',checker:'체커 플래그',aurora:'오로라',ember:'엠버'};
export const DEFAULT_LOOK={helmet:'stripe',helmetColor:'#c5f567',visorColor:'#6ad4e6',suit:'panel',suitColor:'#252c42',accentColor:'#c5f567'};
export function cleanLook(v={}){return {helmet:Object.hasOwn(HELMETS,v.helmet)?v.helmet:DEFAULT_LOOK.helmet,suit:Object.hasOwn(SUITS,v.suit)?v.suit:DEFAULT_LOOK.suit,...Object.fromEntries(['helmetColor','visorColor','suitColor','accentColor'].map(k=>[k,PALETTE.includes(v[k])?v[k]:DEFAULT_LOOK[k]]))}}
export function pixelDriver(look,number=7){
 const l=cleanLook(look),p=[],add=(x,y,w,h,c)=>p.push(`<rect x="${x}" y="${y}" width="${w}" height="${h}" fill="${c}"/>`),shape=(d,c)=>p.push(`<path d="${d}" fill="${c}"/>`),ink='#18222d';
 // A rounded, stepped helmet, relaxed shoulders and offset boots give the sprite a natural stance.
 add(15,75,36,3,'#0004');add(20,78,26,1,'#0002');
 shape('M25 38H40V41H44V44H48V50H50V59H47V62H43V59H42V65H40V72H43V77H32V74H29V77H18V73H21V64H20V58H17V61H12V57H13V49H16V44H21V41H25Z',ink);
 shape('M25 42H39V44H43V50H41V62H23V50H19V46H24Z',l.suitColor);
 shape('M17 46H22V51H20V56H16V57H14V52H16Z',l.suitColor);
 shape('M43 46H46V51H48V57H44V54H42Z',l.suitColor);
 add(16,47,3,7,'#fff2');add(45,51,3,6,'#0003');
 add(14,56,5,4,'#e5e9ed');add(14,56,5,1,l.accentColor);add(15,59,3,1,'#9aa9b7');add(44,57,4,4,'#b8c5cd');add(44,57,4,1,l.accentColor);
 add(25,41,14,3,l.accentColor);add(29,42,6,2,'#e1c3a0');add(30,44,4,2,ink);
 add(24,46,17,12,l.suitColor);add(24,46,3,12,'#fff1');add(38,46,3,15,'#0003');
 if(l.suit==='stripe'){add(25,45,3,16,l.accentColor);add(36,45,3,16,l.accentColor)}
 if(l.suit==='panel'){shape('M24 45H40V50H36V52H28V50H24Z',l.accentColor);add(17,46,5,3,l.accentColor);add(43,46,3,3,l.accentColor)}
 if(l.suit==='checker'){for(let y=46;y<53;y+=2)for(let x=24;x<40;x+=2)if(((x+y)/2)%2===0)add(x,y,2,2,l.accentColor)}
 if(l.suit==='aurora'){shape('M24 46H29L40 56V61H36L24 50Z',l.accentColor);add(17,47,4,2,l.accentColor);add(43,48,4,2,l.accentColor)}
 if(l.suit==='ember'){add(24,45,2,15,l.accentColor);add(38,45,2,15,l.accentColor);shape('M28 47H36V51L32 54L28 51Z',l.accentColor);add(17,46,5,2,l.accentColor)}
 add(26,48,4,2,'#f2f1e9');add(34,48,4,2,'#f2f1e9');add(31,46,1,13,'#ffffff44');
 add(23,60,18,3,ink);add(24,60,16,1,l.accentColor);add(30,60,4,2,'#c3cbd2');
 shape('M23 63H31V68H29V72H22Z',l.suitColor);shape('M33 63H40V72H34V68H33Z',l.suitColor);
 add(23,64,2,7,l.accentColor);add(38,64,2,7,l.accentColor);add(25,66,4,2,'#fff2');add(35,68,3,2,'#0003');
 shape('M22 72H29V75H19V74H22Z','#cfd9df');shape('M34 72H40V74H42V76H34Z','#93a7b6');add(20,75,9,1,l.accentColor);add(34,76,8,1,l.accentColor);
 // Head occupies just under half the full silhouette; chin overlaps a narrow neck.
 shape('M24 4H39V6H45V9H49V14H51V29H49V34H45V38H40V41H25V39H20V36H16V31H14V17H16V11H20V7H24Z',ink);
 shape('M25 6H38V8H44V11H47V16H49V28H47V33H43V36H39V38H26V36H21V33H18V29H16V18H18V12H22V9H25Z',l.helmetColor);
 shape('M25 7H37V9H27V11H22V15H19V20H17V17H19V12H23V9H25Z','#ffffff55');
 shape('M47 18H49V28H47V33H43V36H39V38H27V36H39V34H44V30H46Z','#0003');
 if(l.helmet==='stripe'){add(29,6,6,11,l.accentColor);add(30,6,2,10,'#ffffff30');add(30,34,6,4,l.accentColor)}
 if(l.helmet==='split'){shape('M34 7H38V9H44V12H47V19H34Z',l.accentColor);add(34,32,10,3,l.accentColor)}
 if(l.helmet==='aero'){shape('M44 10H51V13H53V16H47Z',ink);add(45,12,6,2,l.accentColor);shape('M19 31H25V33H43V35H39V37H27V35H22Z',l.accentColor)}
 if(l.helmet==='aurora'){shape('M21 10L26 8L43 16H35Z',l.accentColor);shape('M20 31H26L39 36H30Z',l.accentColor)}
 if(l.helmet==='ember'){add(25,8,3,9,l.accentColor);add(38,9,3,8,l.accentColor);shape('M22 32H27L31 36H26ZM37 32H43L38 36H34Z',l.accentColor)}
 shape('M19 17H46V19H49V27H46V30H21V28H17V21H19Z',ink);
 shape('M21 19H44V21H47V25H44V27H22V25H19V22H21Z',l.visorColor);
 shape('M22 19H38V21H27V23H20V22H22Z','#ffffff90');add(21,25,24,2,'#0004');add(42,20,3,5,'#0002');add(17,22,3,3,'#8797a1');
 add(27,31,12,2,ink);add(29,34,8,1,'#ffffff44');add(43,30,2,2,'#edf2f3');
 const n=Math.max(1,Math.min(99,Number(number)||7));return `<svg class="pixel-driver" viewBox="0 0 64 84" role="img" aria-label="커스터마이징한 도트 레이싱 드라이버" shape-rendering="crispEdges">${p.join('')}<text x="32" y="58" text-anchor="middle" fill="#fff" font-family="monospace" font-weight="bold" font-size="5">${n}</text></svg>`;
}
export function seeded(seed){let h=2166136261;for(const c of String(seed)){h^=c.charCodeAt(0);h=Math.imul(h,16777619)}return()=>{h+=0x6D2B79F5;let t=Math.imul(h^h>>>15,1|h);t^=t+Math.imul(t^t>>>7,61|t);return((t^t>>>14)>>>0)/4294967296}}
export function newCareer(profile,seed){return Object.assign(createCareer(profile),{look:cleanLook(profile.look),seed,log:[],rules:6,raceSystem:profile.raceSystem??7})}
export function act(s,action){if(s.phase==='retired')return false;if((s.rules??4)<6){if(['prepare','season'].includes(s.phase)){evolve(s);if(s.seed)s.log.push({type:'evolve'})}else return legacy.act(s,action)}const racing=(s.raceSystem??6)>=7?dynamicRace:raceV6;const rng=s.seed?seeded(s.seed+':'+s.log.length):Math.random;let ok=false;switch(action.type){case'upgrade':ok=upgradeCar(s,action.value);break;case'train':ok=train(s,action.value);break;case'qualify':ok=qualify(s,rng);break;case'race':if(!['safe','balanced','attack'].includes(action.value))return false;ok=racing.startLive(s,action.value,rng);break;case'progress':ok=racing.progressLive(s,rng);break;case'decision':ok=racing.chooseLive(s,action.value,rng);break;case'advance':ok=advance(s);break;case'contract':if(s.season>=20)return false;ok=nextSeason(s,action.value);break;case'retire':if(!['prepare','season'].includes(s.phase)||s.results.length<1)return false;s.phase='retired';s.retirement={...careerScore(s),retiredAt:new Date().toISOString()};ok=true;break}if(ok&&s.seed)s.log.push({...action});return ok}
export function careerScore(s){let wins=0,podiums=0,points=0;for(const r of s.results){const weight=({1:4,2:2,3:1.5,4:1})[r.division]??1;if(!r.dnf){if(r.pos===1)wins+=250*weight;else if(r.pos<=3)podiums+=80*weight;points+=r.points*10*weight}}const parts={titles:s.titles*10000,wins,podiums,points,ability:overall(s)*20,league:({1:5000,2:2500,3:1000,4:0})[Math.min(s.peakDivision??s.division,s.division)]};const total=Math.round(Object.values(parts).reduce((a,b)=>a+b,0));return {total,parts,grade:total>=150000?'레전드':total>=70000?'월드 클래스':total>=25000?'챔피언':total>=8000?'프로 드라이버':'라이징 루키'}}
export function replay(profile,seed,log){if(!Array.isArray(log)||log.length>6000)throw new Error('기록 길이가 올바르지 않습니다.');const s=(profile.rules??6)>=6?newCareer(profile,seed):legacy.newCareer(profile,seed);for(const a of log){if(a?.type==='race-update'&&(s.raceSystem??6)<7&&(s.rules??4)>=6&&['prepare','season'].includes(s.phase)){updateRace(s);s.log.push({...a});continue}if(a?.type==='evolve'&&(s.rules??4)<6&&['prepare','season'].includes(s.phase)){evolve(s);s.log.push({...a});continue}const apply=(s.rules??4)<6?legacy.act:act;if(!a||!apply(s,a))throw new Error('유효하지 않은 플레이 기록입니다.')}if(s.phase!=='retired')throw new Error('은퇴가 완료되지 않았습니다.');return s}
function evolve(s){initializeDevelopment(s);s.rules=6;s.raceSystem=6;s.history.unshift({season:s.season,text:'선수 훈련·차량 개발·영입 시장 업데이트 적용. 기존 기록과 잔액을 이어갑니다.'});return s}
export function koreaDay(date=new Date()){return new Date(date.getTime()+9*3600000).toISOString().slice(0,10)}
export function migrate(s){if(!validSave(s))return null;if((s.rules??4)<6&&['prepare','season'].includes(s.phase)){evolve(s);if(s.seed)s.log.push({type:'evolve'})}if((s.raceSystem??6)<7&&['prepare','season'].includes(s.phase)){updateRace(s);if(s.seed)s.log.push({type:'race-update'})}s.look=cleanLook(s.look??{helmetColor:s.color,accentColor:s.color});return s}

function updateRace(s){s.raceSystem=7;return s}
