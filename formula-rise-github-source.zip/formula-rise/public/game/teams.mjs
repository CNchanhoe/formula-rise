import {REGIONAL_TEAMS} from './regional-teams.mjs';
// Fictional constructor identities. Stable internal IDs preserve older save data.
const team=(id,name,short,color,car=2,badge=0)=>({id,name,short,color,car,logo:`/constructor-marks/constructor-${String(badge).padStart(2,'0')}.svg`,desc:'포뮬러 라이즈 오리지널 팀'});
const common={
 invicta:team('invictaracing','Lumen Works','LUM','#87d2dc',5,0),hitech:team('hitech','Cinder Union','CIN','#88b7f0',3,1),campos:team('camposracing','Vector Forge','VEC','#c4b0a0',4,2),dams:team('damslucasoil','Nightwave Racing','NIG','#bfd08b',2,3),mp:team('mpmotorsport','Polar Circuit','POL','#f1798b',3,4),prema:team('premaracing','Cloudline Atelier','CLO','#d6c17e',5,5),rodin:team('rodinmotorsport','Basalt Engineering','BAS','#e6a87e',2,6),art:team('artgrandprix','Ion Foundry','ION','#b2b8e2',4,7),aix:team('aixracing','Tidal Motors','TID','#b9a0ef',0,8),var:team('vanamersfoortracing','Grove Dynamics','GRO','#a4c998',1,9),trident:team('trident','Quartz Division','QUA','#8db7bd',3,10)
};
export const TEAMSETS={
 1:[team('mercedes','Cobalt Arrow','COB','#87d2dc',5,11),team('ferrari','Emberline Sport','EMB','#88b7f0',5,12),team('mclaren','Horizon Assembly','HOR','#c4b0a0',5,13),team('redbullracing','Sable Motorsport','SAB','#bfd08b',4,14),team('racingbulls','Copperlane','COP','#f1798b',2,15),team('alpine','Vale Collective','VAL','#d6c17e',1,16),team('haasf1team','Orbit Racing','ORB','#e6a87e',1,17),team('audi','Mistral Works','MIS','#b2b8e2',2,18),team('williams','Indigo Labs','IND','#b9a0ef',2,19),team('astonmartin','Pioneer Circuit','PIO','#a4c998',3,20),team('cadillac','Arcstone','ARC','#8db7bd',0,21)],
 2:['invicta','hitech','campos','dams','mp','prema','rodin','art','aix','var','trident'].map(k=>common[k]),
 3:['campos','trident','mp','art','var','rodin','prema','hitech','aix','dams'].map(k=>common[k]),
 4:[team('akm','Crescent Motorsport','CRE','#87d2dc',0,22),team('alpha54','Lyra Racing','LYR','#88b7f0',0,23),team('as','Opal Engineering','OPA','#c4b0a0',1,24),team('cram','Kestrel Works','KES','#bfd08b',2,25),team('jenzer','Cove Racing','COV','#f1798b',3,26),team('maffi','Fable Motorsport','FAB','#d6c17e',1,27),team('pa','Beacon Sport','BEA','#e6a87e',0,28),team('phm','Tangent Racing','TAN','#b2b8e2',2,29),team('prema-f4','Northvale','NOR','#b9a0ef',5,30),team('racegp','Echo Circuit','ECH','#a4c998',3,31),team('real','Juniper Works','JUN','#8db7bd',0,32),team('trident-f4','Solstice Racing','SOL','#87d2dc',4,33),team('us','Slate Union','SLA','#88b7f0',5,34),team('var-f4','Mariner Sport','MAR','#c4b0a0',4,35)]
};
export const teamsFor=(division,region='italy')=>division===4?(REGIONAL_TEAMS[region]??TEAMSETS[4]):(TEAMSETS[division]??TEAMSETS[4]);
export const seatsFor=division=>division===3?3:2;
export const teamMark=t=>`<img class="team-mark " src="${t.logo}" alt="${t.name} 로고" loading="lazy" width="40" height="28">`;
