import {teamsFor} from './teams.mjs';
export const CAR_KEYS=['speed','handling','tyres','reliability'];
export const CAR_LABELS=['최고 속도','핸들링','타이어 성능','냉각·신뢰성'];
export const PHYSICAL_HELP=['브레이킹과 스타트에 반응하는 속도','고속 코너에서 차량을 버티는 근력','추월 기회와 레이스 흐름을 읽는 감각','긴 스틴트의 집중과 타이어 관리를 뒷받침하는 지구력','압박 속 실수를 줄이고 일정한 페이스를 지키는 능력','빗길과 달라지는 노면에 적응하는 감각'];
export const dollars=n=>'$'+Math.round(n||0).toLocaleString('en-US');
export function upgradeGain(s,key){const v=s.stats[key];return Math.round((v<60?2.8:v<75?2:v<88?1.5:.9)*(s.age>35?.6:s.age>31?.8:1)*10)/10}
export const garageKey=s=>`${s.region??'italy'}:${s.division}:${s.team}`;
export function carLevels(s){return s.garages?.[garageKey(s)]??Object.fromEntries(CAR_KEYS.map(k=>[k,0]))}
export function carStats(s,team=s.team){const t=teamsFor(s.division,s.region)[team],base=({4:44,3:58,2:70,1:80})[s.division]+t.car*1.8,levels=team===s.team?carLevels(s):{};return Object.fromEntries(CAR_KEYS.map(k=>[k,Math.min(99,Math.round((base+(levels[k]??0)*1.5)*10)/10)]))}
export function upgradeCost(s,key){if(!CAR_KEYS.includes(key))return Infinity;const lv=carLevels(s)[key];return Math.round(({4:650,3:2800,2:13000,1:95000})[s.division]*Math.pow(1+lv*.65,1.45))}
export function upgradeCar(s,key){if(s.phase!=='prepare'||!CAR_KEYS.includes(key)||carLevels(s)[key]>=8)return false;const cost=upgradeCost(s,key);if(s.money<cost)return false;s.money-=cost;s.finance.spent+=cost;s.garages[garageKey(s)]={...carLevels(s),[key]:carLevels(s)[key]+1};return true}
export function salaryFor(division,team,reputation=0,region='italy'){return Math.round(({4:12000,3:65000,2:280000,1:1800000})[division]*(1+teamsFor(division,region)[team].car*.16)*(1+Math.min(100,reputation)*.008))}
export function prizeFor(s,pos,dnf){if(dnf)return 0;const pool=({4:3000,3:16000,2:75000,1:400000})[s.division];return Math.round(pool*(pos===1?1:pos<=3?.65:pos<=10?.4/(1+(pos-4)*.22):.06))}
export function initializeDevelopment(s){s.region??='italy';s.garages??={};s.finance??={salary:0,prizes:0,bonuses:0,spent:0};s.reputation??=Math.min(90,s.wins*2+s.podiums+s.titles*10);s.peakDivision??=Math.min(s.division,...s.results.map(r=>r.division));s.contract??={salary:salaryFor(s.division,s.team,s.reputation,s.region),kind:'rookie'};s.seasonHistory??=[];return s}
