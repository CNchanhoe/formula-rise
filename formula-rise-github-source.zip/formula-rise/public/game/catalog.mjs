export const PRODUCTS=[
 {id:'aurora-kit',name:'오로라 레이싱 키트',type:'cosmetic',price:1900,tag:'AURORA / 01',description:'사선 패널과 빛의 궤적을 담은 헬멧·유니폼 세트.',look:{helmet:'aurora',suit:'aurora',helmetColor:'#252c42',visorColor:'#6ad4e6',suitColor:'#252c42',accentColor:'#b3a0ff'}},
 {id:'ember-kit',name:'엠버 레이싱 키트',type:'cosmetic',price:1900,tag:'EMBER / 02',description:'날카로운 핀 스트라이프와 어깨 배지가 있는 레이싱 세트.',look:{helmet:'ember',suit:'ember',helmetColor:'#252c42',visorColor:'#f4d35e',suitColor:'#252c42',accentColor:'#ff875d'}},
 {id:'career-slots',name:'커리어 슬롯 +2',type:'slots',price:3900,tag:'CAREER / EXPANSION',description:'기본 1칸에 2칸을 추가해 총 3개의 커리어를 나란히 보관합니다.'}
];
export const productById=id=>PRODUCTS.find(p=>p.id===id);
export const won=n=>Number(n).toLocaleString('ko-KR')+'원';
export const slotLimit=owned=>owned.includes('career-slots')?3:1;
export const requiredProduct=look=>PRODUCTS.find(p=>p.look&&(p.look.helmet===look?.helmet||p.look.suit===look?.suit))?.id??null;
export const canWear=(look,owned)=>['helmet','suit'].every(k=>{const product=PRODUCTS.find(p=>p.look?.[k]===look?.[k]);return !product||owned.includes(product.id)});
