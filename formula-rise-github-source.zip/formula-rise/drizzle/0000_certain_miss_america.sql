CREATE TABLE `careers` (
	`id` text PRIMARY KEY NOT NULL,
	`token_hash` text NOT NULL,
	`device_hash` text NOT NULL,
	`seed` text NOT NULL,
	`profile` text NOT NULL,
	`created_at` text NOT NULL,
	`created_day` text NOT NULL
);
--> statement-breakpoint
CREATE TABLE `records` (
	`id` text PRIMARY KEY NOT NULL,
	`day` text NOT NULL,
	`name` text NOT NULL,
	`score` integer NOT NULL,
	`titles` integer NOT NULL,
	`ovr` integer NOT NULL,
	`summary` text NOT NULL,
	`created_at` text NOT NULL
);
--> statement-breakpoint
CREATE INDEX `records_day_score` ON `records` (`day`,`score`);