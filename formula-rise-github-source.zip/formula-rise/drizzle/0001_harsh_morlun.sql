CREATE TABLE `shop_entitlements` (
	`id` text PRIMARY KEY NOT NULL,
	`wallet_id` text NOT NULL,
	`product_id` text NOT NULL,
	`order_id` text NOT NULL,
	`active` integer NOT NULL,
	`updated_at` text NOT NULL
);
--> statement-breakpoint
CREATE TABLE `shop_orders` (
	`id` text PRIMARY KEY NOT NULL,
	`wallet_id` text NOT NULL,
	`product_id` text NOT NULL,
	`amount` integer NOT NULL,
	`status` text NOT NULL,
	`payment_key` text,
	`created_at` text NOT NULL,
	`updated_at` text NOT NULL
);
--> statement-breakpoint
CREATE INDEX `shop_wallet_orders` ON `shop_orders` (`wallet_id`,`created_at`);--> statement-breakpoint
CREATE TABLE `shop_wallets` (
	`id` text PRIMARY KEY NOT NULL,
	`token_hash` text NOT NULL,
	`created_at` text NOT NULL
);
--> statement-breakpoint
CREATE UNIQUE INDEX `shop_wallets_token_hash_unique` ON `shop_wallets` (`token_hash`);