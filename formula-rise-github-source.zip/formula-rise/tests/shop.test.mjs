import test from 'node:test';
import assert from 'node:assert/strict';
import {DatabaseSync} from 'node:sqlite';
import {readFileSync} from 'node:fs';
import {handleShop,shopConfig,digest} from '../lib/shop-service.mjs';
import {PRODUCTS,canWear,slotLimit} from '../public/game/catalog.mjs';
import {readSlots,persistSlots,selectSlot,putSlot,SLOT_KEY,LEGACY_KEY} from '../public/game/slots.mjs';
import {newCareer,act,careerScore} from '../public/game/career.mjs';
const origin='https://game.example';
function setup(){
 const sqlite=new DatabaseSync(':memory:');
 for(const file of ['0001_harsh_morlun.sql','0002_aromatic_the_phantom.sql'])sqlite.exec(readFileSync(new URL('../drizzle/'+file,import.meta.url),'utf8'));
 const db={prepare(sql){const stmt=sqlite.prepare(sql);let args=[];return {bind(...v){args=v;return this},first:async()=>stmt.get(...args)??null,all:async()=>({results:stmt.all(...args)}),run:async()=>stmt.run(...args)}},async batch(queries){sqlite.exec('BEGIN');try{const results=[];for(const q of queries)results.push(await q.run());sqlite.exec('COMMIT');return results}catch(e){sqlite.exec('ROLLBACK');throw e}}};
 const env={SHOP_ENABLED:'true',TOSS_CLIENT_KEY:'live_ck_fixture',TOSS_SECRET_KEY:'live_sk_fixture',SHOP_SELLER_NAME:'Fixture',SHOP_SUPPORT_EMAIL:'support@example.com',SHOP_TERMS_URL:origin+'/terms',SHOP_PRIVACY_URL:origin+'/privacy',SHOP_REFUND_URL:origin+'/refund'};
 let payment=null,calls=0;const fetcher=async()=>{calls++;return payment?Response.json(payment):Response.json({error:'not found'},{status:404})};
 const request=async(action,body={},token,config=env)=>{const req=new Request(origin+'/api/shop/'+action,{method:'POST',headers:{Origin:origin,'Content-Type':'application/json',...(token?{Authorization:'Bearer '+token}:{})},body:JSON.stringify(body)});const response=await handleShop(req,{db,env:config,fetcher});return {status:response.status,...await response.json()}};
 return {sqlite,db,env,request,setPayment:p=>payment=p,calls:()=>calls};
}
test('closed catalog never exposes server secrets or creates a wallet',async()=>{const t=setup();try{assert.equal((await t.request('wallet',{},null,{})).status,503);assert.equal(t.calls(),0);const cfg=shopConfig(t.env);assert.equal(cfg.ready,true);assert.ok(!JSON.stringify(cfg).includes('live_sk_'));assert.equal(shopConfig({...t.env,SHOP_TERMS_URL:'javascript:alert(1)'}).ready,false)}finally{t.sqlite.close()}});
test('payment grants require provider verification and exact server amount; cancellation revokes',async()=>{const t=setup();try{
 const w=await t.request('wallet');assert.equal(w.status,201);assert.match(w.token,/^[a-f0-9]{64}$/);assert.equal(t.sqlite.prepare('SELECT token_hash FROM shop_wallets').get().token_hash,await digest(w.token));
 const data={productId:'aurora-kit',accepted:true,recoverySaved:true};
 const order=await t.request('order',data,w.token);assert.equal(order.amount,1900);assert.equal((await t.request('order',data,w.token)).orderId,order.orderId);
 const forged=await t.request('confirm',{orderId:order.orderId,amount:1,paymentKey:'pk'},w.token);assert.equal(forged.status,409);assert.equal(t.calls(),0);
 const other=await t.request('wallet');assert.equal((await t.request('confirm',{orderId:order.orderId,amount:1900,paymentKey:'pk'},other.token)).status,404);
 const payment={orderId:order.orderId,totalAmount:1900,balanceAmount:1900,currency:'KRW',type:'NORMAL',paymentKey:'pk',status:'READY'};
 t.setPayment(payment);assert.equal((await t.request('confirm',{orderId:order.orderId,amount:1900,paymentKey:'pk'},w.token)).status,409);assert.deepEqual((await t.request('owned',{},w.token)).owned,[]);
 t.setPayment({...payment,status:'DONE'});const body={orderId:order.orderId,amount:1900,paymentKey:'pk'};assert.deepEqual((await t.request('confirm',body,w.token)).owned,['aurora-kit']);assert.equal((await t.request('confirm',body,w.token)).status,200);assert.equal((await t.request('order',data,w.token)).status,409);
 t.setPayment({...payment,status:'CANCELED',balanceAmount:0});await t.request('webhook',{data:{orderId:order.orderId,status:'DONE'}});assert.deepEqual((await t.request('owned',{},w.token)).owned,[]);assert.equal((await t.request('confirm',body,w.token)).status,409);
 const replacement=await t.request('order',data,w.token);assert.notEqual(replacement.orderId,order.orderId);t.setPayment({...payment,orderId:replacement.orderId,paymentKey:'pk2',status:'DONE'});await t.request('confirm',{orderId:replacement.orderId,amount:1900,paymentKey:'pk2'},w.token);
 t.setPayment({...payment,status:'CANCELED',balanceAmount:0});await t.request('webhook',{data:{orderId:order.orderId}});assert.deepEqual((await t.request('owned',{},w.token)).owned,['aurora-kit']);
 }finally{t.sqlite.close()}});
test('forged webhook cannot grant unpaid products; missing wallet is unauthorized',async()=>{const t=setup();try{const w=await t.request('wallet');const order=await t.request('order',{productId:'career-slots',accepted:true,recoverySaved:true},w.token);assert.equal((await t.request('webhook',{data:{orderId:order.orderId,status:'DONE'}})).status,502);assert.deepEqual((await t.request('owned',{},w.token)).owned,[]);assert.equal((await t.request('owned')).status,401)}finally{t.sqlite.close()}});
test('legacy save is read without overwriting, slots are separate, corrupt bank stays intact',()=>{
 const values=new Map([[LEGACY_KEY,JSON.stringify({name:'Original'})]]);const storage={getItem:k=>values.get(k)??null,setItem:(k,v)=>values.set(k,v),removeItem:k=>values.delete(k)};const valid=s=>typeof s?.name==='string';
 let bank=readSlots(storage,valid);assert.equal(values.has(SLOT_KEY),false);assert.equal(bank.slots[0].name,'Original');assert.throws(()=>selectSlot(bank,1,1));bank=putSlot(selectSlot(bank,1,3),{name:'Second'});persistSlots(storage,bank);assert.equal(readSlots(storage,valid).slots[0].name,'Original');assert.equal(readSlots(storage,valid).slots[1].name,'Second');
 const before=values.get(SLOT_KEY);assert.throws(()=>persistSlots({...storage,setItem(){throw new Error('quota')}},putSlot(bank,null)));assert.equal(values.get(SLOT_KEY),before);
 values.set(SLOT_KEY,'{"version":1,"slots":[],"active":0}');assert.throws(()=>readSlots(storage,valid));assert.ok(values.has(LEGACY_KEY));
});
test('mixed premium looks require both entitlements and cosmetics do not affect race results',()=>{
 assert.equal(slotLimit([]),1);assert.equal(slotLimit(['career-slots']),3);assert.equal(canWear({helmet:'aurora',suit:'ember'},['aurora-kit']),false);assert.equal(canWear({helmet:'aurora',suit:'ember'},['aurora-kit','ember-kit']),true);
 const profile={name:'Tester',number:7,nation:'대한민국',style:'balanced',rules:6,raceSystem:7,region:'italy'};
 const states=[newCareer(profile,'cosmetic-test'),newCareer({...profile,look:PRODUCTS[0].look},'cosmetic-test')];for(const s of states){act(s,{type:'qualify'});act(s,{type:'race',value:'safe'});while(s.phase==='racing'){act(s,s.live.event?{type:'decision',value:s.live.event.options.at(-1).id}:{type:'progress'})}}assert.deepEqual(states[0].results,states[1].results);assert.equal(careerScore(states[0]).total,careerScore(states[1]).total);
});
