import test from 'node:test';
import assert from 'node:assert/strict';
import {newCareer,act} from '../public/game/career.mjs';
import {makeEvent,chooseLive,progressLive} from '../public/game/racing-v6.mjs';
import {retirementInfo} from '../public/game/retirement.mjs';
import {raceView} from '../public/game/race-view.mjs';
const start=()=>{const s=newCareer({name:'DNF 검증',style:'balanced',raceSystem:6},'dnf');act(s,{type:'qualify'});act(s,{type:'race',value:'safe'});return s};
const rngSequence=(...values)=>()=>values.length?values.shift():.9;
function onlyPlayer(s){s.live.cars=s.live.cars.filter(c=>c.id==='you');return s}
test('background incident, puncture and decision risks preserve exact cause and lap',()=>{
 const incident=onlyPlayer(start());progressLive(incident,rngSequence(.5,0));assert.deepEqual(incident.lastRace.retirement,{code:'incident',lap:1});
 const puncture=onlyPlayer(start());puncture.live.wear=5;progressLive(puncture,rngSequence(.5,.9,0));assert.equal(puncture.lastRace.retirement.code,'puncture');
 for(const [risk,code] of [[.15,'wet_spin'],[.07,'overpush']]){const s=onlyPlayer(start());s.live.risk=risk;progressLive(s,rngSequence(.5,.9,0));assert.equal(s.lastRace.retirement.code,code);assert.equal(s.lastRace.retirement.lap,1)}
});
test('contact, fire damage and voluntary stop retain cause in results and history',()=>{
 for(const [choice,code] of [['send','contact'],['repair','fire_damage'],['stop','safety_stop']]){const s=start();s.live.stage=choice==='send'?1:4;s.live.lap=choice==='send'?4:20;s.live.event=makeEvent(s,()=>0);chooseLive(s,choice,()=>0);assert.equal(s.live.retired,true);assert.equal(s.live.retirement.code,code);progressLive(s,()=>.5);assert.equal(s.lastRace.dnf,true);assert.equal(s.lastRace.points,0);assert.equal(s.results[0].retirement.code,code);assert.equal(s.lastRace.retirement.lap,choice==='send'?4:20);const html=raceView(s);assert.match(html,/DNF · 리타이어/);assert.ok(html.includes(retirementInfo(s.live.retirement).title));assert.match(html,/다음 경기는 계속할 수 있습니다/);assert.doesNotMatch(html,/CHEQUERED FLAG|radio-panel/)}
});
test('successful choices do not report a retirement; old saves never invent a cause',()=>{
 const s=start();s.live.stage=1;s.live.lap=4;s.live.event=makeEvent(s,()=>.5);chooseLive(s,'send',()=>.1);assert.equal(s.live.retired,false);assert.equal(s.live.retirement,undefined);assert.equal(retirementInfo(undefined).title,'원인 미기록');s.live.retired=true;const me=s.live.cars.find(c=>c.id==='you');me.retired=true;progressLive(s,()=>.5);assert.match(raceView(s),/원인 미기록/);
});
