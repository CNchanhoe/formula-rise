'use client';
import {useEffect} from 'react';
export default function Home(){useEffect(()=>{if(document.querySelector('script[data-grid-app]'))return;const script=document.createElement('script');script.type='module';script.src='/game/app.mjs?v=8';script.dataset.gridApp='true';script.onerror=()=>{const root=document.getElementById('app');if(root)root.textContent='게임을 불러오지 못했습니다. 새로고침해주세요.'};document.body.appendChild(script)},[]);return <><div id="app"><p style={{padding:40,color:'#c5f567'}}>패독을 준비하고 있어요…</p></div><div id="toast" role="status"/><dialog id="modal"/></>}
