import {env} from 'cloudflare:workers';
import {handleShop} from '../../../../lib/shop-service.mjs';
export async function GET(req:Request){return handleShop(req,{db:env.DB,env,fetcher:fetch});}
export async function POST(req:Request){return handleShop(req,{db:env.DB,env,fetcher:fetch});}
