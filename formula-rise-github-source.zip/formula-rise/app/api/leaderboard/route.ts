export {getLeaderboard as GET} from '../../../lib/leaderboard';
