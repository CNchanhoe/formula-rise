export {updateAppearance as POST} from '../../../lib/leaderboard';
