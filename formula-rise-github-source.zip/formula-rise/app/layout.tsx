import type {Metadata} from 'next';
export const metadata:Metadata={title:'포뮬러 라이즈 — 포뮬러 레이싱 커리어',description:'로그인 없이 만드는 나만의 도트 드라이버. 포뮬러 월드 챔피언과 오늘의 커리어 랭킹에 도전하세요.'};
export default function RootLayout({children}:{children:React.ReactNode}){return <html lang="ko"><head><link rel="icon" href="/formula-rise.svg"/><meta name="theme-color" content="#111313"/><link rel="stylesheet" href="/game/style.css?v=8"/></head><body>{children}</body></html>}
