# GitHub 이전

## 현재 준비 상태

- 저장소명 제안: `formula-rise`
- 기본 공개 범위: 비공개. 상용 게임 소스 공개는 별도 결정합니다.
- 현재 사이트와 로컬 소스는 보존합니다.
- `.github/workflows/checks.yml`에 테스트·타입 검사·빌드 검증을 준비했습니다.
- 비공개 저장소: https://github.com/CNchanhoe/formula-rise
- 최신 검증 결과는 저장소의 Actions 탭에서 확인합니다.

## 업로드 대상

게임·API·DB 마이그레이션·빌드 도구·문서·lockfile을 함께 올립니다. 환경 변수, 결제 비밀 키, 구매 복구 키, 사용자 저장 파일, 로컬 DB, node_modules, 빌드 산출물, Sites 임시 인증은 올리지 않습니다.

기존 Git 기록에는 이전 실팀 이미지가 남아 있을 수 있습니다. 신규 GitHub 저장소에는 현재 소스의 깨끗한 스냅샷으로 시작하는 방식을 권장합니다. 기존 Sites Git 기록은 그대로 보존합니다. 제공된 `formula-rise-github-source.zip`은 Git 기록과 로컬 데이터를 제외한 현재 소스입니다.

후속 변경은 위 저장소의 main 브랜치 또는 검토용 브랜치로 업로드합니다. 토큰을 코드나 채팅에 넣지 않습니다. 자동 배포는 계정과 호스팅을 결정한 뒤 연결합니다.

## 호스팅

GitHub Pages는 정적 호스팅입니다. 현재 `/api/careers`, `/api/retire`, `/api/leaderboard`, `/api/shop/*`, `/api/appearance`를 처리할 Worker와 D1이 필요합니다. 정적 파일만 Pages에 올리면 새 커리어 생성부터 실패합니다.

1. 우선 GitHub에 코드만 관리하고 기존 Sites URL을 운영합니다.
2. 나중에 독립 Cloudflare Workers + D1을 선택하면 프로젝트명·DB 바인딩·배포 설정을 실제 계정에 맞춥니다.
3. 기존 D1 데이터는 Git에 포함되지 않습니다. 호스팅을 옮길 때 별도로 백업·이관하고 커리어 검증·구매 권한이 유지되는지 확인합니다.
4. 도메인이 바뀌면 이용자에게 기존 주소에서 커리어 파일과 구매 복구 키를 내보내도록 안내합니다.
5. 새 주소에서 저장 파일 복원, 레이스, 은퇴 등록, 구매 권한 복원을 검증한 후 전환합니다.

참고: [GitHub Pages 지원 범위](https://docs.github.com/en/pages/getting-started-with-github-pages/creating-a-github-pages-site), [Cloudflare Git 연동](https://developers.cloudflare.com/workers/ci-cd/builds/git-integration/).
